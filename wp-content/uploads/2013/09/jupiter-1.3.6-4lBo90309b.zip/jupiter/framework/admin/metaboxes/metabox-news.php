<?php
$config  = array(
  'title' => sprintf( '%s News Options', THEME_NAME ),
  'id' => 'mk-metaboxes-tabs',
  'pages' => array(
    'news'
  ),
  'callback' => '',
  'context' => 'normal',
  'priority' => 'core'
);
$options = array(


  array(
    "type" => "start_sub",
    "options" => array(
      "General Setting" => __( "General Setting", 'mk_framework' ),
    ),
  ),




  array(
    "type" => "start_sub_pane"
  ),

  array(
    "name" => __( "Post Options", "mk_framework" ),
    "desc" => __( "", "mk_framework" ),
    "type" => "heading"
  ),
  array(
    "name" => __( "Custom Page Title", "mk_framework" ),
    "desc" => __( "If left Blank the global title which you defined in masterkey settings will be used. You can optionally use a different page title in banner section from this option.", "mk_framework" ),
    "id" => "_custom_page_title",
    "default" => "",
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "text"
  ),

  array(
    "name" => __( "Layout", "mk_framework" ),
    "desc" => __( "Please choose this page's layout.", "mk_framework" ),
    "id" => "_layout",
    "default" => 'default',
    "option_structure" => 'sub',
    "divider" => true,
    "item_padding" => "0 30px 30px 0",
    "options" => array(
      "left" => 'page-layout-left',
      "right" => 'page-layout-right',
      "full" => 'page-layout-full',
      "default" => 'page-layout-default',
    ),
    "type" => "visual_selector"
  ),
  array(
    "name" => __("Post Style", "mk_framework" ),
    "desc" => __( "", "mk_framework" ),
    "id" => "_news_post_style",
    "default" => 'full-with-image',
    "preview" => false,
    "options" => array(
      "full-with-image" => __( "Full With Image", "mk_framework" ),
      "full-without-image" => __( "Full Without Image", "mk_framework" ),
      "half-with-image" => __( "Half With Image", "mk_framework" ),
      "half-without-image" => __( "Half Without Image", "mk_framework" ),
      "fourth-with-image" => __( "One Fourth With Image", "mk_framework" ),
      "fourth-without-image" => __( "One Fourth Without Image", "mk_framework" ),
    ),
    "option_structure" => 'sub',
    "divider" => true,

    "type" => "select"
  ),


  array(
    "name" => __("Custom Sidebar", "mk_framework" ),
    "desc" => __( "You can create a custom sidebar, under Sidebar option and then assign the custom sidebar here to this post. later on you can customize which widgets to show up.", "mk_framework" ),
    "id" => "_sidebar",
    "default" => '',
    "options" => get_sidebar_options(),
    "option_structure" => 'sub',
    "divider" => false,
    "margin_bottom" => 200,
    "type" => "chosen_select"
  ),


  array(
    "type"=>"end_sub_pane"
  ),
  /*****************************/









  array(
    "type"=>"end_sub"
  ),


);
new metaboxesGenerator( $config, $options );
