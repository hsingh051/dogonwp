<?php
$config  = array(
  'title' => sprintf( '%s Posts Options', THEME_NAME ),
  'id' => 'mk-metaboxes-tabs',
  'pages' => array(
    'post'
  ),
  'callback' => '',
  'context' => 'normal',
  'priority' => 'core'
);
$options = array(


  array(
    "type" => "start_sub",
    "options" => array(
      "general" => __( "General Settings", 'mk_framework' ),
      "post-type" => __( "Post Type", 'mk_framework' ),
      "single-post-options" => __( "Single Post Options", 'mk_framework' ),
    ),
  ),



  array(
    "type" => "start_sub_pane"
  ),

  array(
    "name" => __("General Settings", "mk_framework" ),
    "desc" => __( "", "mk_framework" ),
    "type" => "heading"
  ),
  array(
    "name" => __( "Custom Page Title", "mk_framework" ),
    "desc" => __( "If left Blank the global title which you defined in masterkey settings will be used. You can optionally use a different page title in banner section from this option.", "mk_framework" ),
    "id" => "_custom_page_title",
    "default" => "",
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "text"
  ),
  array(
    "name" => __( "Layout", "mk_framework" ),
    "desc" => __( "Please choose this page's layout.", "mk_framework" ),
    "id" => "_layout",
    "default" => 'default',
    "option_structure" => 'sub',
    "divider" => true,
    "item_padding" => "0 30px 30px 0",
    "options" => array(
      "left" => 'page-layout-left',
      "right" => 'page-layout-right',
      "full" => 'page-layout-full',
      "default" => 'page-layout-default',
    ),
    "type" => "visual_selector"
  ),

  array(
    "name" => __("Custom Sidebar", "mk_framework" ),
    "desc" => __( "You can create a custom sidebar, under Sidebar option then assign the custom sidebar here to this post.", "mk_framework" ),
    "id" => "_sidebar",
    "default" => '',
    "option_structure" => 'sub',
    "divider" => true,
    "options" => get_sidebar_options(),
    "margin_bottom" => 200,
    "type" => "chosen_select"
  ),



  array(
    "type"=>"end_sub_pane"
  ),
  /*****************************/





  /* Sub Pane one : Logo Option */
  array(
    "type" => "start_sub_pane"
  ),

  array(
    "name" => __( "Post Options", "mk_framework" ),
    "desc" => __( "", "mk_framework" ),
    "type" => "heading"
  ),
  array(
    "name" => __( "Featured Image Lightbox in Blog Loop", "mk_framework" ),
    "desc" => __( "By default if user click on featured images in blog loop a lightbox will be opened. However you can disable this feature and instead once user clicked on featured image it will go through to single post.", "mk_framework" ),
    "id" => "_disable_post_lightbox",
    "default" => 'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),

  array(
    "name" => __("Post Type", "mk_framework" ),
    "desc" => __( "", "mk_framework" ),
    "id" => "_single_post_type",
    "default" => 'image',
    "preview" => false,
    "options" => array(
      "image" => 'Image',
      "video" => 'Video',
      "audio" => 'Audio',
      "portfolio" => 'Portfolio',
    ),
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "chosen_select"
  ),

  array(
    "name" => __( "Classic Loops Style Orientation", "mk_framework" ),
    "desc" => __( "This option allows you to choose how the blog loop item be displayed. This option only applies to Classic style.", "mk_framework" ),
    "id" => "_classic_orientation",
    "default" => 'landscape',
    "option_structure" => 'sub',
    "divider" => true,
    "options" => array(
      "landscape" => 'Landscape',
      "portraite" => 'Portrait',
    ),
    "type" => "select"
  ),

  array(
    "name" => __( "Upload MP3 File", "mk_framework" ),
    "desc" => __( "Upload MP3 your file or paste the full URL for external files. This file formated needed for Safari, Internet Explorer, Chrome. ", "mk_framework" ),
    "id" => "_mp3_file",
    "preview" => false,
    "default" => "",
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "upload"
  ),

  array(
    "name" => __( "Upload OGG File", "mk_framework" ),
    "desc" => __( "Upload OGG your file or paste the full URL for external files. This file formated needed for Firefox, Opera, Chrome. ", "mk_framework" ),
    "id" => "_ogg_file",
    "preview" => false,
    "default" => "",
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "upload"
  ),
  array(
    "name" => __( "Sound Track Author", "mk_framework" ),
    "desc" => __( "Fill this Field If you would like to state the author of the audio file you are about to post.", "mk_framework" ),
    "id" => "_single_audio_author",
    "size" => 50,
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "text"
  ),

  array(
    "name" => __( "Video Site", "mk_framework" ),
    "id" => "_single_video_site",
    "default" => 'youtube',
    "option_structure" => 'sub',
    "divider" => true,
    "options" => array(
      "vimeo" => 'Vimeo',
      "youtube" => 'Youtube',
      "dailymotion" => 'Daily Motion',
      //"custom" => 'Custom Video',
    ),
    "type" => "select"
  ),

  array(
    "name" => __( "Video Id", "mk_framework" ),
    "desc" => __( "Please fill this option with the required ID. you can find the ID from the link parameters as examplified below:<br /> http://www.youtube.com/watch?v=<strong>ID</strong><br />https://vimeo.com/<strong>ID</strong><br />http://www.dailymotion.com/embed/video/<strong>ID</strong>", "mk_framework" ),
    "id" => "_single_video_id",
    "size" => 20,
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "text"
  ),






  array(
    "type"=>"end_sub_pane"
  ),
  /*****************************/





  /* Sub Pane one : Post Single Option */
  array(
    "type" => "start_sub_pane"
  ),

  array(
    "name" => __( "Featured Image", "mk_framework" ),
    "desc" => __( "If you do not want to set a featured image (in case of sound post type : Audio player, in case of video post type : Video Player) kindly disable it here.", "mk_framework" ),
    "id" => "_disable_featured_image",
    "default" => 'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),
  array(
    "name" => __( "Meta Section", "mk_framework" ),
    "id" => "_disable_meta",
    "default" => 'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),
  array(
    "name" => __( "Tags", "mk_framework" ),
    "desc" => __( "Tags could be disabled using this option should you not want to include any tags", "mk_framework" ),
    "id" => "_disable_tags",
    "default" =>'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),
  array(
    "name" => __( "Related Posts", "mk_framework" ),
    "desc" => __( "If you do not want to show related posts disable the post here", "mk_framework" ),
    "id" => "_disable_related_posts",
    "default" =>'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),
  array(
    "name" => __( "About Author Box", "mk_framework" ),
    "desc" => __( "Disable the about author box here", "mk_framework" ),
    "id" => "_disable_about_author",
    "default" => 'true',
    "option_structure" => 'sub',
    "divider" => true,
    "type" => "toggle"
  ),

  array(
    "type"=>"end_sub_pane"
  ),
  /*****************************/




  array(
    "type"=>"end_sub"
  ),


);
new metaboxesGenerator( $config, $options );
