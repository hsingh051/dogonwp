<?php



class WPBakeryShortCode_VC_Column_text extends WPBakeryShortCode {

}

class WPBakeryShortCode_mk_table extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_icon_box extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_mini_callout extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_custom_sidebar extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_gallery extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_social_networks extends WPBakeryShortCode {
}
class WPBakeryShortCode_vc_tweetme extends WPBakeryShortCode {
}

class WPBakeryShortCode_vc_googleplus extends WPBakeryShortCode {
}

class WPBakeryShortCode_vc_twitter extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_skype extends WPBakeryShortCode {
}
class WPBakeryShortCode_mk_moving_image extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_font_icons extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_blockquote extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_milestone extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_dropcaps extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_highlight extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_tooltip extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_skill_meter extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_skill_meter_chart extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_chart extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_steps extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_custom_list extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_message_box extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_divider extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_button extends WPBakeryShortCode {

}

class WPBakeryShortCode_mk_toggle extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_fancy_title extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_title_box extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_circle_image extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_pricing_table extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_employees extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_clients extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_testimonials extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_flexslider extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_layerslider extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_revslider extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_woocommerce_recent_carousel extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_image_slideshow extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_fullwidth_slideshow extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_Laptop_slideshow extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_lcd_slideshow extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_padding_divider extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_contact_form extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_faq extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_contact_info extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_portfolio_carousel extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_blog_carousel extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_blog_showcase extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_audio extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_countdown extends WPBakeryShortCode {
}

class WPBakeryShortCode_mk_clearboth extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_flickr extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Facebook extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Gmaps extends WPBakeryShortCode {
}

class WPBakeryShortCode_VC_Video extends WPBakeryShortCode {

}

class WPBakeryShortCode_VC_pinterest extends WPBakeryShortCode {

}


class WPBakeryShortCode_mk_news_tab extends WPBakeryShortCode {
}