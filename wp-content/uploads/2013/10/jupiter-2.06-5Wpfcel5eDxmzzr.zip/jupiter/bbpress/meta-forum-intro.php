<?php
?>

<p>We will do our best to assist you with any issues/bugs related to the use of our themes and plugins. Unfortunately we do not provide support for customizations or using 3rd party plugins. <a href="http://artbees.net/support/support-policy/"><strong>Read our full support policy here.</strong></a></p>

<div id="forums-search">
	<form role="search" method="get" id="searchform" class="searchform" action="<?php echo site_url('/search') ?>">
		<input type="text" value="" name="q" class="search" placeholder="Search the forums..">
		<input type="submit" class="searchsubmit" value="Search">
	</form>
</div>

<br/>
<hr/>