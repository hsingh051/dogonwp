<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link href="<?php echo get_template_directory_uri();?>/css/bootstrap.css" type="text/css" rel="stylesheet" />
<link href="<?php echo get_template_directory_uri();?>/css/custom.css" type="text/css" rel="stylesheet" />
<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
	<div class="top_bar">
		<div class="container">
			df
		</div>
	</div>